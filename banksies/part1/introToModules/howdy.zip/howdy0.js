// when trying howdy0 in your server, try consolelogging 'howdy' to see what it is

console.log('howdy');