// when trying howdy1 in your server, try consolelogging 'howdy' to see what it is
// calling 'howdy' runs this file top to bottom like any old script

module.exports.sayIt = function () {
	console.log('howdy')
};