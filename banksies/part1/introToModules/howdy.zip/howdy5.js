var howdy = {};

howdy.sayIt = function () {
	console.log('howdy');
};

module.exports = howdy;

var turtle = 5;

// it's good practice, but not necessary, to put it at the end