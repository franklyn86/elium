var howdy = {};

howdy.sayIt = function () {
	console.log('howdy');
};

module.exports = howdy;

var turtle = 5;
module.exports = turtle;

// module statements overwrite themselves, do only one  