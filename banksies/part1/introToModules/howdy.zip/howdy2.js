var howdy = {};

howdy.sayIt = function () {
	console.log('howdy');
};

module.exports = howdy;